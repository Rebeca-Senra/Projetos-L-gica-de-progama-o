﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnResultado_Click(object sender, EventArgs e)
        {
            //Entrada
            int idade = int.Parse(txtIdade.Text);
            int resultado; 

            //Proceso
            resultado = idade * 12;
            //Saída
            MessageBox.Show("Idade em meses ="+ resultado);

        }

        private void btnResultDolar_Click(object sender, EventArgs e)
        {
            //Entrada
            float dolar = float.Parse(txtDolar.Text);
            float resultado;

            //Proceso
            resultado = dolar * 5;
            //Saída
            MessageBox.Show("Valor em reais " + resultado);
        }
    }
}
