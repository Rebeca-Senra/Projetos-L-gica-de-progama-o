﻿namespace Atividade_1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtIdade = new System.Windows.Forms.TextBox();
            this.lblIdade = new System.Windows.Forms.Label();
            this.btnResultado = new System.Windows.Forms.Button();
            this.btnResultDolar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDolar = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtIdade
            // 
            this.txtIdade.Location = new System.Drawing.Point(77, 162);
            this.txtIdade.Name = "txtIdade";
            this.txtIdade.Size = new System.Drawing.Size(254, 20);
            this.txtIdade.TabIndex = 0;
            this.txtIdade.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblIdade
            // 
            this.lblIdade.AutoSize = true;
            this.lblIdade.Location = new System.Drawing.Point(101, 126);
            this.lblIdade.Name = "lblIdade";
            this.lblIdade.Size = new System.Drawing.Size(34, 13);
            this.lblIdade.TabIndex = 1;
            this.lblIdade.Text = "Idade";
            this.lblIdade.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnResultado
            // 
            this.btnResultado.Location = new System.Drawing.Point(90, 203);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(103, 27);
            this.btnResultado.TabIndex = 2;
            this.btnResultado.Text = "Resultado";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // btnResultDolar
            // 
            this.btnResultDolar.Location = new System.Drawing.Point(486, 250);
            this.btnResultDolar.Name = "btnResultDolar";
            this.btnResultDolar.Size = new System.Drawing.Size(103, 27);
            this.btnResultDolar.TabIndex = 5;
            this.btnResultDolar.Text = "Resultado";
            this.btnResultDolar.UseVisualStyleBackColor = true;
            this.btnResultDolar.Click += new System.EventHandler(this.btnResultDolar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(494, 126);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Dolar";
            // 
            // txtDolar
            // 
            this.txtDolar.Location = new System.Drawing.Point(470, 162);
            this.txtDolar.Name = "txtDolar";
            this.txtDolar.Size = new System.Drawing.Size(254, 20);
            this.txtDolar.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnResultDolar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtDolar);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.lblIdade);
            this.Controls.Add(this.txtIdade);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIdade;
        private System.Windows.Forms.Label lblIdade;
        private System.Windows.Forms.Button btnResultado;
        private System.Windows.Forms.Button btnResultDolar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDolar;
    }
}

