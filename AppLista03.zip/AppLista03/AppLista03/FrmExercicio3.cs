﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void pnlTopo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblQuilo_Click(object sender, EventArgs e)
        {

        }

        private void pnlBase_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //pegar valor tela
            float peso = float.Parse(txtPeso.Text);
            float valorPagar;
                //calcular
                valorPagar = peso * 34.00f;
            //Mostrar resultado
           lblValor.Text = "Valor refeição" + valorPagar;
        }
    }
}
