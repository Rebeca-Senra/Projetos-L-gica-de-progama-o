﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {//Pegar dados tela
            float vlrPago = float.Parse(txtPagar.Text);
            float vlrLitro = float.Parse(txtGasolina.Text);
            float totalLitros;
            //Calculo
            totalLitros = vlrPago / vlrLitro;
            lblResultado.Text = "Abasteceu com" + totalLitros + "litro(s)";


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void FrmExercicio2_Load(object sender, EventArgs e)
        {

        }
    }
}
