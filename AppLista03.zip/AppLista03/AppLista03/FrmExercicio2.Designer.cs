﻿namespace AppLista03
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPagar = new System.Windows.Forms.Label();
            this.lblGasolina = new System.Windows.Forms.Label();
            this.txtPagar = new System.Windows.Forms.TextBox();
            this.txtGasolina = new System.Windows.Forms.TextBox();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlTopo = new System.Windows.Forms.Panel();
            this.pnlBase = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPagar
            // 
            this.lblPagar.AutoSize = true;
            this.lblPagar.Location = new System.Drawing.Point(87, 97);
            this.lblPagar.Name = "lblPagar";
            this.lblPagar.Size = new System.Drawing.Size(70, 13);
            this.lblPagar.TabIndex = 0;
            this.lblPagar.Text = "Valor a pagar";
            // 
            // lblGasolina
            // 
            this.lblGasolina.AutoSize = true;
            this.lblGasolina.Location = new System.Drawing.Point(87, 161);
            this.lblGasolina.Name = "lblGasolina";
            this.lblGasolina.Size = new System.Drawing.Size(92, 13);
            this.lblGasolina.TabIndex = 1;
            this.lblGasolina.Text = "Valor litro gasolina";
            // 
            // txtPagar
            // 
            this.txtPagar.Location = new System.Drawing.Point(77, 119);
            this.txtPagar.Name = "txtPagar";
            this.txtPagar.Size = new System.Drawing.Size(148, 20);
            this.txtPagar.TabIndex = 2;
            // 
            // txtGasolina
            // 
            this.txtGasolina.Location = new System.Drawing.Point(77, 197);
            this.txtGasolina.Name = "txtGasolina";
            this.txtGasolina.Size = new System.Drawing.Size(148, 20);
            this.txtGasolina.TabIndex = 3;
            this.txtGasolina.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(138, 250);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(110, 34);
            this.btnCalcular.TabIndex = 4;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.button1_Click);
            // 
            // pnlTopo
            // 
            this.pnlTopo.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pnlTopo.Location = new System.Drawing.Point(9, 12);
            this.pnlTopo.Name = "pnlTopo";
            this.pnlTopo.Size = new System.Drawing.Size(761, 67);
            this.pnlTopo.TabIndex = 5;
            // 
            // pnlBase
            // 
            this.pnlBase.BackColor = System.Drawing.SystemColors.HotTrack;
            this.pnlBase.Location = new System.Drawing.Point(12, 371);
            this.pnlBase.Name = "pnlBase";
            this.pnlBase.Size = new System.Drawing.Size(761, 67);
            this.pnlBase.TabIndex = 6;
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Location = new System.Drawing.Point(170, 346);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(55, 13);
            this.lblResultado.TabIndex = 7;
            this.lblResultado.Text = "Resultado";
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.pnlBase);
            this.Controls.Add(this.lblPagar);
            this.Controls.Add(this.pnlTopo);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.txtGasolina);
            this.Controls.Add(this.txtPagar);
            this.Controls.Add(this.lblGasolina);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.Load += new System.EventHandler(this.FrmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPagar;
        private System.Windows.Forms.Label lblGasolina;
        private System.Windows.Forms.TextBox txtPagar;
        private System.Windows.Forms.TextBox txtGasolina;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Panel pnlTopo;
        private System.Windows.Forms.Panel pnlBase;
        private System.Windows.Forms.Label lblResultado;
    }
}