﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmExercicio1 : Form
    {
        public FrmExercicio1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Pegar tela valores
            float num1 = float.Parse(txtNum1.Text);
            float num3 = float.Parse(txtNum2.Text);
            float soma;
            //Processamento fazer contas
            soma = num1 + num3;
            //Sáída 
            lblRSoma.Text = "Soma igua a" + soma;
        }   


          

private void lblRSoma_Click(object sender, EventArgs e)
        {

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float media;
            //Processamento
            media = (num1 + num2 + num3) / 3;
            //Saída
            lblRMedia.Text = "Média igual a" + media;

        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtNum1.Text);
            float num2 = float.Parse(txtNum2.Text);
            float num3 = float.Parse(txtNum3.Text);
            float total, porcNum1, porcNum2, porcNum3;
            //Processamento
            total = num1 + num2 + num3;//100%
            porcNum1 = num1 / total;
            porcNum2 =num2/ total;
            porcNum3 = num3 / total;
            lblRPorcentagem.Text="Numero um é"+porcNum1+  "Numero dois é:"+porcNum2+"Numero tres é:" + porcNum3;

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
